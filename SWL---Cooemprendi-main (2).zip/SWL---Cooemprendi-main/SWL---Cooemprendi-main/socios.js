// Memoria temporal para guardar los socios
let listaSocios = [];

// Capturar elementos de la pantalla
const formSocios = document.getElementById('form-socios');
const tablaSocios = document.getElementById('lista-socios');

// Procesar el formulario de socios
formSocios.addEventListener('submit', function(evento) {
    evento.preventDefault();

    // Obtener los datos del formulario
    const nombre = document.getElementById('socio-nombre').value;
    const idSocio = document.getElementById('socio-id').value;
    const telefono = document.getElementById('socio-telefono').value;

    // Guardar el registro
    listaSocios.push({ id: idSocio, nombre: nombre, telefono: telefono });

    // Actualizar la pantalla
    actualizarTablaSocios();
    formSocios.reset();
});

function actualizarTablaSocios() {
    tablaSocios.innerHTML = ""; // Limpiar tabla

    listaSocios.forEach(function(socio) {
        const fila = document.createElement('tr');
        fila.innerHTML = `<td>${socio.id}</td><td>${socio.nombre}</td><td>${socio.telefono}</td>`;
        tablaSocios.appendChild(fila);
    });
}
