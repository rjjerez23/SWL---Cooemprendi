// Memoria temporal para guardar los ahorros
let listaAhorros = [];
let totalAcumulado = 0;

// Capturar elementos de la pantalla
const formAhorros = document.getElementById('form-ahorros');
const tablaAhorros = document.getElementById('lista-ahorros');
const totalPantalla = document.getElementById('total-general');

// Procesar el formulario cuando se envía
formAhorros.addEventListener('submit', function(evento) {
    evento.preventDefault(); // Evita que la página se recargue

    // Obtener los datos escritos por el usuario
    const socio = document.getElementById('ahorro-socio').value;
    const monto = parseFloat(document.getElementById('ahorro-monto').value);

    // Guardar el registro en la lista
    listaAhorros.push({ socio: socio, monto: monto });
    totalAcumulado += monto;

    // Actualizar la pantalla
    actualizarTablaAhorros();
    formAhorros.reset(); // Limpiar casillas
});

function actualizarTablaAhorros() {
    tablaAhorros.innerHTML = ""; // Limpiar tabla

    listaAhorros.forEach(function(item) {
        const fila = document.createElement('tr');
        fila.innerHTML = `<td>${item.socio}</td><td>$${item.monto.toFixed(2)}</td>`;
        tablaAhorros.appendChild(fila);
    });

    totalPantalla.textContent = totalAcumulado.toFixed(2);
}
